# SOCKET HTTPS ( DOS HTTPS :> )

** <-- METHOD ALL --> **

TLS_MIX

RENEGOTIATE RENEGOTIATEV2

STRONG

CONTENT_RECV

HUGE_ALL HUGE_ALLv2

** AMPLIFICATION SIZE ( LIKE ) **

WEIRD

X_FORWARDED

HIGH_SIZE

# PROOF ( check-host )

check-report/119fb534k2a2 ( chat227.net ) ( HUGE_ALLv2 )

check-report/119fb5afk8f4 ( queenslot.com ) ( HUGE_ALLv2 )

check-report/119fb9bekfc9 ( godslot.net ) ( HIGH_SIZE )

check-report/119fbb86k506 ( godslotpg.com ) ( STRONG )
